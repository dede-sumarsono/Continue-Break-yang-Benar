/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gaji_karyawan_dede;

import java.util.Scanner;
public class Gaji_Karyawan_Dede {
    
    static void cabang(Long gaji){
        
        if(gaji>=20000000){
            System.out.println("Anda adalah Direktur");
        }
        else if(gaji >=10000000){
            System.out.println("Anda adalah Manager");
        }
        else if(gaji >=7000000){
            System.out.println("Anda adalah Kepala Bagian");
        }
        else if(gaji <7000000){
            System.out.println("Anda adalah Karyawan Produksi");
        }
        
    }

    public static void main(String[] args) {
        
        Scanner maji = new Scanner(System.in);
        
        Long gaji;
        
        System.out.println("Masukan Gaji anda tanpa menggunakan titik!");
        
        gaji = maji.nextLong();
        
        cabang(gaji);
        //PAKAI STR_REPLACE
        
         
        
        
    }
}
